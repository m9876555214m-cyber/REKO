# REKO Pro 0.4 — مشروع Android

هذا هو **المشروع الجاهز للرفع إلى GitHub**. يجب رفع محتويات هذا المجلد نفسها إلى جذر مستودع REKO، وليس ملف ZIP داخل المستودع.

## الملفات الرئيسية
- `.github/workflows/build-apk.yml` — يبني APK تلقائياً على GitHub Actions.
- `app/` — تطبيق Android.
- `build.gradle.kts` و `settings.gradle.kts` — إعدادات البناء.

## بناء APK على GitHub
1. ارفع جميع محتويات المشروع إلى جذر مستودع `REKO`.
2. افتح تبويب **Actions**.
3. اختر **Build REKO APK**.
4. اضغط **Run workflow** أو ادفع التغييرات إلى `main`.
5. بعد نجاح البناء، افتح الـworkflow ثم قسم **Artifacts** وحمّل `REKO-debug-apk`.

## تنبيه أمني
لا تضع مفتاح API سري داخل التطبيق أو داخل GitHub. النسخة الحالية تستخدم Endpoint وAPI Key من إعدادات التطبيق لأغراض التطوير فقط. للنسخة النهائية نستخدم خادماً وسيطاً لحماية المفتاح.
