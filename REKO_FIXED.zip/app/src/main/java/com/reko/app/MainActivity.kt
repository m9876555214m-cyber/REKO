package com.reko.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("reko", MODE_PRIVATE) }
    private var endpoint = ""
    private var apiKey = ""

    override fun onCreate(b: Bundle?) { super.onCreate(b); endpoint=prefs.getString("endpoint","")?:""; apiKey=prefs.getString("key","")?:""; tts=TextToSpeech(this,this); buildUi(); restoreHistory() }

    private fun buildUi() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,14);setBackgroundColor(Color.rgb(13,15,20))}
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text="REKO";textSize=29f;setTextColor(Color.WHITE);setTypeface(null,1)}
        val sub=TextView(this).apply{text="  مساعدك الشخصي";textSize=14f;setTextColor(Color.LTGRAY)}
        val settings=Button(this).apply{text="⚙";setOnClickListener{settingsDialog()}}
        head.addView(title);head.addView(sub,LinearLayout.LayoutParams(0,60,1f));head.addView(settings,LinearLayout.LayoutParams(58,60))
        chat=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(2,12,2,12)}
        val scroll=ScrollView(this).apply{addView(chat);post{fullScroll(View.FOCUS_DOWN)}}
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        input=EditText(this).apply{hint="احكي مع ريكو...";setHintTextColor(Color.GRAY);setTextColor(Color.WHITE);setPadding(16,0,16,0);setSingleLine(false);setBackgroundColor(Color.rgb(30,33,42))}
        val mic=Button(this).apply{text="🎙";setOnClickListener{listen()}}
        val send=Button(this).apply{text="إرسال";setOnClickListener{sendText()}}
        bar.addView(input,LinearLayout.LayoutParams(0,62,1f));bar.addView(mic,LinearLayout.LayoutParams(65,62));bar.addView(send,LinearLayout.LayoutParams(82,62))
        root.addView(head);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));root.addView(bar);setContentView(root)
    }

    private fun restoreHistory(){ val h=prefs.getString("history","") ?: ""; if(h.isBlank()) addBubble("ريكو","مرحبا محمد ❤️\nأنا ريكو. احكي معي كتابة أو بالصوت.",false,false) else h.split("\n---\n").filter{it.isNotBlank()}.takeLast(40).forEach{val p=it.split("|",limit=2);if(p.size==2)addBubble(p[0],p[1],p[0]=="أنت",false)} }
    private fun saveLine(who:String,text:String){ val old=prefs.getString("history","")?:""; val entry=who+"|"+text; val n=(if(old.isBlank()) entry else old+"\n---\n"+entry).takeLast(12000); prefs.edit().putString("history",n).apply() }
    private fun addBubble(who:String,text:String,user:Boolean,save:Boolean=true){val v=TextView(this).apply{text="$who\n$text";textSize=16f;setTextColor(Color.WHITE);setPadding(18,14,18,14);setBackgroundColor(if(user)Color.rgb(50,55,70) else Color.rgb(28,31,40));gravity=if(user)Gravity.END else Gravity.START};chat.addView(v,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)});if(save)saveLine(who,text)}

    private fun sendText(){val q=input.text.toString().trim();if(q.isEmpty())return;input.text.clear();addBubble("أنت",q,true);if(endpoint.isBlank()){addBubble("ريكو","لسه ما ربطنا محرك الذكاء. افتح ⚙ وحط Endpoint آمن، وبعدها رح جاوبك من الخدمة السحابية.",false);return};callAi(q)}
    private fun callAi(q:String){addBubble("ريكو","عم فكّر...",false,false);thread{try{val body="""{"messages":[{"role":"system","content":"أنت REKO، مساعد شخصي ودود. أجب بالعربية السورية بشكل طبيعي ومختصر ما لم يطلب المستخدم التفصيل."},{"role":"user","content":${json(q)}}]}""";val c=URL(endpoint).openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=20000;c.readTimeout=30000;c.setRequestProperty("Content-Type","application/json");if(apiKey.isNotBlank())c.setRequestProperty("Authorization","Bearer $apiKey");c.doOutput=true;c.outputStream.use{it.write(body.toByteArray())};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val r=BufferedReader(InputStreamReader(stream)).readText();runOnUiThread{addBubble("ريكو",if(code in 200..299)extractReply(r) else "خطأ من الخدمة ($code): $r",false);if(code in 200..299)speak(extractReply(r))}}catch(e:Exception){runOnUiThread{addBubble("ريكو","ما قدرت اتصل بالخدمة: ${e.message}",false)}}}}

    private fun extractReply(raw:String):String {
        val trimmed=raw.trim()
        val marker="\"content\":"
        val i=trimmed.indexOf(marker)
        if(i>=0){
            val start=i+marker.length
            val end=trimmed.indexOf("\"",start+1)
            if(end>start) return trimmed.substring(start+1,end).replace("\\n","\n").replace("\\\"","\"")
        }
        return trimmed.removePrefix("{\"response\":").removeSuffix("}").trim('\"')
    }
    private fun json(s:String)= "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\""
    private fun listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10);return};val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-SY");putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)};startActivityForResult(i,20)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==20&&c==RESULT_OK){val t=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:return;input.setText(t);sendText()}}
    override fun onInit(status:Int){tts.language=Locale("ar","SY");tts.setSpeechRate(.95f)}
    private fun speak(s:String){tts.speak(s.take(1000),TextToSpeech.QUEUE_FLUSH,null,"reko")}
    private fun settingsDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,8,30,8)};val e=EditText(this).apply{hint="Endpoint";setText(endpoint)};val k=EditText(this).apply{hint="API Key";setText(apiKey);inputType=129};box.addView(e);box.addView(k);AlertDialog.Builder(this).setTitle("إعدادات ريكو").setView(box).setPositiveButton("حفظ"){_,_->endpoint=e.text.toString().trim();apiKey=k.text.toString().trim();prefs.edit().putString("endpoint",endpoint).putString("key",apiKey).apply();Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show()}.setNeutralButton("مسح المحادثة"){_,_->prefs.edit().remove("history").apply();chat.removeAllViews();addBubble("ريكو","تم مسح الذاكرة المحلية.",false)}.setNegativeButton("إلغاء",null).show()}
    override fun onDestroy(){tts.stop();tts.shutdown();super.onDestroy()}
}
